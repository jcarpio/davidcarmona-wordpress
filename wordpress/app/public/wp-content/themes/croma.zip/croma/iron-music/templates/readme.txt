You can modify the event and album template by copying the templates files from the plugin directory to this directory
