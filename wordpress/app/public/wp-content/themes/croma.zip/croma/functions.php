<?php require_once(get_template_directory().'/includes/classes/iron_croma.class.php');

// Setup Theme
Iron_Croma::setup();